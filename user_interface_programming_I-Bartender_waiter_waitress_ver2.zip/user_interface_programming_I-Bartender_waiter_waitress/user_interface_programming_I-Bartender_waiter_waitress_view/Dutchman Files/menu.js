const menuData = [
    {
        "id": 1,
        "name": "Dish 1",
        "description": "Some description",
        "price": 12.99
    },
    {
        "id": 2,
        "name": "Dish 2",
        "description": "Some description",
        "price": 9.99
    },
    {
        "id": 3,
        "name": "Dish 3",
        "description": "Some description",
        "price": 11.99
    },
    {
        "id": 4,
        "name": "Dish 4",
        "description": "Some description",
        "price": 4.99
    }]
